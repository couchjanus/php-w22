// bada base
let products = [
   {
      "id": 1,
      "image": "images/product-1.jpg",
      "name": "Kui Ye Chen’s AirPods",
      "price": 123,
      "badge": "Soldout",
      "bgBadge":"danger",
      "category": "electronics"
   },
   {
      "id": 2,
      "image": "images/product-2.jpg",
      "name": "Air bag",
      "price": 121,
      "badge": "",
      "bgBadge":"",
      "category": "bags"
   },
   {
      "id": 3,
      "image": "images/product-3.jpg",
      "name": "Men's T-Shirt",
      "price": 223,
      "badge": "New",
      "bgBadge":"info",
      "category": "clothes"
   },
   {
      "id": 4,
      "image": "images/product-4.jpg",
      "name": "Kui Ye watch",
      "price": 321,
      "badge": "",
      "bgBadge":"",
      "category": "watches"
   },
   {
      "id": 5,
      "image": "images/product-5.jpg",
      "name": "Red digital smartwatch",
      "price": 111,
      "badge": "Action",
      "bgBadge":"warning",
      "category": "electronics"
   },
   {
      "id": 6,
      "image": "images/product-6.jpg",
      "name": "Nike air max 95",
      "price": 222,
      "badge": "",
      "bgBadge":"",
      "category": "shoes"
   },
   {
      "id": 7,
      "image": "images/product-7.jpg",
      "name": "Joemalone Women prefume",
      "price": 13,
      "badge": "",
      "bgBadge":"",
      "category": "cosmetics"
   },
   {
      "id": 8,
      "image": "images/product-8.jpg",
      "name": "Apple Watch",
      "price": 333,
      "badge": "Soldout",
      "bgBadge":"danger",
      "category": "electronics"
   }
];

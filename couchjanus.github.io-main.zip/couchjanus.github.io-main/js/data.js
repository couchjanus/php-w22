let products = [
    {
        id:1,
        image:"images/product-1.jpg",
        name:"Kui Ye Chen’s AirPods",
        'price': '232.88',
        'badge': 'Soldout',
        'bgBadge':'danger',
        category: 'gadgets' 
    },
    {
        id:2,
        image:"images/product-2.jpg",
        name:"Kui Ye Chen’s AirPods",
        'price': '123.88',
        'badge': '',
        'bgBadge':'' ,
        category: 'bags'
    },
    {
        id:3,
        image:"images/product-3.jpg",
        name:"Kui Ye Chen’s AirPods",
        'price': '333.88',
        'badge': 'New', 
        'bgBadge':'info' ,
        category: 'clothes'
    },
    {
        id:4,
        image:"images/product-4.jpg",
        name:"Kui Ye Chen’s AirPods",
        'price': '444.88',
        'badge': '',
        'bgBadge':'' ,
        category: 'watches'
    },
    {
        id:5,
        image:"images/product-5.jpg",
        name:"Red digital smartwatch",
        'price': '555.88',
        'badge': 'Action',
        'bgBadge':'warning',
        category: 'watches'  
    },
    {
        id:6,
        image:"images/product-6.jpg",
        name:"Nike air max 95",
        'price': '66.88',
        'badge': '',
        'bgBadge':'',
        category: 'shoes' 
    },
];